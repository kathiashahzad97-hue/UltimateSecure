package com.ultimatesafety.mobile

data class ScanResult(val level: String, val score: Int, val reasons: List<String>, val advice: String)

/** Offline heuristic demo only. It is not an antivirus or a live reputation service. */
object ScamAnalyzer {
    private val phrases = listOf(
        "you won", "claim prize", "urgent", "verify account", "bank details", "send otp",
        "share otp", "account blocked", "free gift", "investment guaranteed",
        "aap jeet gaye", "inaam hasil", "foran click", "account band", "otp bhejein",
        "muft inaam", "paise bhejein", "job fee", "registration fee"
    )

    fun analyze(text: String): ScanResult {
        val value = text.lowercase()
        val reasons = mutableListOf<String>()
        var score = 0
        if (Regex("https?://|www\\.").containsMatchIn(value)) {
            score += 15
            reasons += "Message mein web link mojood hai."
        }
        if (Regex("https?://\\d{1,3}(\\.\\d{1,3}){3}").containsMatchIn(value)) {
            score += 30
            reasons += "Link mein numeric IP address use hua hai."
        }
        val found = phrases.filter { value.contains(it) }
        if (found.isNotEmpty()) {
            score += (found.size * 15).coerceAtMost(45)
            reasons += "Prize, urgency, OTP ya payment se mutaliq suspicious alfaaz mile."
        }
        if (Regex("\\b(otp|password|pin|cvv|bank details)\\b").containsMatchIn(value)) {
            score += 20
            reasons += "Sensitive account information maangi ja sakti hai."
        }
        score = score.coerceIn(0, 100)
        val level = when { score >= 60 -> "High risk"; score >= 30 -> "Caution"; else -> "No obvious warning signs" }
        val advice = when {
            score >= 60 -> "Link na kholein aur OTP, PIN, password ya bank details share na karein. Official channel se tasdeeq karein."
            score >= 30 -> "Sender aur website ko independently verify karein. Jaldi mein payment ya login na karein."
            else -> "Koi obvious warning sign nahi mila. Is ka matlab guaranteed safe hona nahi hai."
        }
        if (reasons.isEmpty()) reasons += "Is simple offline check mein listed warning pattern nahi mila."
        return ScanResult(level, score, reasons, advice)
    }
}
