# Ultimate Safety — Android MVP Starter

Pakistan-first native Android prototype built with Kotlin and Jetpack Compose.

## Included
- Native Compose dashboard
- Offline heuristic message / URL pattern checker
- Roman Urdu safety guidance
- App Lock PIN screen foundation
- Privacy guidance screen

## Important limitations
- Scam Shield is a simple offline heuristic. It does not query live threat intelligence, inspect website content, or prove that a message is safe.
- App Lock does NOT yet block or intercept other Android apps. The screen is only a UI foundation.
- Urdu assistant is static rule-based guidance, not a connected generative AI.
- No internet permission, analytics, ads SDK, or backend is included.

## Open and run
1. Install Android Studio and Android SDK.
2. Open this folder in Android Studio.
3. Allow Gradle sync. Use JDK 17 for this Android Gradle Plugin version.
4. Run on an Android 8.0+ device or emulator.

## Next milestones
1. Add unit tests and a curated Pakistan scam-pattern test corpus.
2. Add secure PIN storage using Android Keystore-backed cryptography.
3. Implement real app-lock enforcement only after reviewing current Android APIs, background restrictions, Accessibility policy, and Google Play requirements.
4. Add trusted URL reputation checks with explicit privacy disclosures.
5. Add opt-in Urdu/Roman Urdu AI assistance; do not upload message contents without user consent.
6. Complete security, privacy, accessibility and device compatibility testing.
