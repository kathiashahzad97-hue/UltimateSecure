package com.ultimatesafety.mobile

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { UltimateSafetyApp() }
    }
}

private enum class Screen { HOME, SCAM, LOCK, ASSISTANT, PRIVACY }

@Composable
private fun UltimateSafetyApp() {
    var screen by remember { mutableStateOf(Screen.HOME) }
    MaterialTheme(colorScheme = darkColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF55D6A5), secondary = androidx.compose.ui.graphics.Color(0xFF72B7F2), background = androidx.compose.ui.graphics.Color(0xFF081522), surface = androidx.compose.ui.graphics.Color(0xFF102438))) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column {
                Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Shield, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(34.dp))
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("ULTIMATE SAFETY", fontWeight = FontWeight.Black, fontSize = 19.sp)
                        Text("YOUR DIGITAL PROTECTION PARTNER", fontSize = 9.sp, color = MaterialTheme.colorScheme.secondary)
                    }
                }
                when (screen) {
                    Screen.HOME -> HomeScreen({ screen = Screen.SCAM }, { screen = Screen.LOCK }, { screen = Screen.ASSISTANT }, { screen = Screen.PRIVACY })
                    Screen.SCAM -> ScamScreen { screen = Screen.HOME }
                    Screen.LOCK -> LockScreen { screen = Screen.HOME }
                    Screen.ASSISTANT -> AssistantScreen { screen = Screen.HOME }
                    Screen.PRIVACY -> PrivacyScreen { screen = Screen.HOME }
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(scam: () -> Unit, lock: () -> Unit, assistant: () -> Unit, privacy: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(20.dp)) {
                Text("YOUR SAFETY, IN ONE PLACE", color = MaterialTheme.colorScheme.secondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Stay alert. Stay protected.", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Apne messages aur links check karein. Online hifazat ka aghaz ehtiyat se hota hai.")
                Spacer(Modifier.height(12.dp))
                Text("Prototype build • Local analysis only", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("SECURITY TOOLS", fontWeight = FontWeight.Bold)
        ToolCard("Scam Shield", "Suspicious message aur URL ka offline check", Icons.Default.TravelExplore, scam)
        ToolCard("App Lock", "PIN setup foundation", Icons.Default.Lock, lock)
        ToolCard("Urdu Safety Assistant", "Asaan zuban mein security guidance", Icons.Default.Chat, assistant)
        ToolCard("Privacy Center", "Permissions aur privacy guidance", Icons.Default.Security, privacy)
        Text("Reminder: Koi scan 100% safety guarantee nahi karta.", color = MaterialTheme.colorScheme.secondary, fontSize = 12.sp, modifier = Modifier.padding(top = 12.dp))
    }
}

@Composable
private fun ToolCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(17.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Bold); Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .7f)) }
            Icon(Icons.Default.ChevronRight, null)
        }
    }
}

@Composable
private fun Header(title: String, back: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = back) { Icon(Icons.Default.ArrowBack, "Back") }
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ScamScreen(back: () -> Unit) {
    var input by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<ScanResult?>(null) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Header("Scam Shield", back)
        Text("Message ya URL paste karein")
        OutlinedTextField(value = input, onValueChange = { input = it; result = null }, modifier = Modifier.fillMaxWidth(), minLines = 5, placeholder = { Text("Suspicious message ya link yahan paste karein...") })
        Button(onClick = { result = ScamAnalyzer.analyze(input) }, enabled = input.isNotBlank(), modifier = Modifier.fillMaxWidth().padding(top = 10.dp)) { Icon(Icons.Default.Search, null); Spacer(Modifier.width(8.dp)); Text("Analyze") }
        result?.let { r ->
            Card(Modifier.fillMaxWidth().padding(top = 14.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(16.dp)) {
                    Text(r.level, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = if (r.score >= 60) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
                    Text("Prototype risk score: ${r.score}/100")
                    r.reasons.forEach { Text("• $it", Modifier.padding(top = 5.dp)) }
                    Spacer(Modifier.height(8.dp)); Text("Kya karein?", fontWeight = FontWeight.Bold); Text(r.advice)
                }
            }
        }
        Text("Yeh offline prototype hai. Live threat database, antivirus scan ya website reputation check nahi karta.", color = MaterialTheme.colorScheme.secondary, fontSize = 12.sp, modifier = Modifier.padding(top = 12.dp))
    }
}

@Composable
private fun LockScreen(back: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("Yeh sirf PIN screen foundation hai; abhi doosri apps ko lock nahi karta.") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Header("App Lock", back)
        Text("PIN setup prototype", fontWeight = FontWeight.Bold)
        OutlinedTextField(value = pin, onValueChange = { if (it.length <= 6 && it.all(Char::isDigit)) pin = it }, label = { Text("4–6 digit PIN") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), modifier = Modifier.fillMaxWidth())
        Button(onClick = { message = if (pin.length in 4..6) "PIN format valid hai. Secure storage aur real app-lock enforcement next stage mein banega." else "4 se 6 digits ka PIN enter karein." }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp)) { Text("Validate PIN") }
        Text(message, modifier = Modifier.padding(top = 12.dp))
        Text("Real app lock ke liye Android foreground detection, user-granted access, lock activity, biometrics aur Google Play policy review zaroori honge.", color = MaterialTheme.colorScheme.secondary, fontSize = 12.sp, modifier = Modifier.padding(top = 12.dp))
    }
}

@Composable
private fun AssistantScreen(back: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Header("Urdu Safety Assistant", back)
        Text("Digital safety ke zaroori rules", fontWeight = FontWeight.Bold)
        listOf("Apna OTP, PIN ya password kisi ko na dein.", "Bank ka link message se kholne ke bajaye official app use karein.", "Prize ya job ke naam par advance fee dene se pehle verify karein.", "Unknown APK files install na karein.", "Suspicious message ko verify kiye baghair forward na karein.").forEachIndexed { i, tip ->
            Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) { Text("${i + 1}. $tip", Modifier.padding(14.dp)) }
        }
        Text("Yeh static offline guidance hai, generative AI service nahi.", color = MaterialTheme.colorScheme.secondary, fontSize = 12.sp)
    }
}

@Composable
private fun PrivacyScreen(back: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Header("Privacy Center", back)
        Text("Android Settings mein permissions review karein:", fontWeight = FontWeight.Bold)
        listOf("Camera: sirf zaroorat par allow karein.", "Microphone: unknown apps ko access na dein.", "Location: while-in-use access ko tarjeeh dein.", "Contacts aur SMS: sirf trusted apps ko dein.", "Ghair-zaroori apps uninstall karein.").forEach { Text("• $it", Modifier.padding(vertical = 8.dp)) }
        Text("Is prototype ne abhi device permissions scan nahi ki hain.", color = MaterialTheme.colorScheme.secondary, fontSize = 12.sp)
    }
}
